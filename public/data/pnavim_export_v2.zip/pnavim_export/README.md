# Export PNAVIM-CI - Fichiers Marchands et Marchés

Ce dossier contient tous les fichiers relatifs aux **marchands** et aux **marchés** extraits du projet PNAVIM-CI pour intégration sur une autre plateforme.

## Structure des Fichiers

```
pnavim_export/
├── merchants/                    # Pages principales des marchands
│   ├── MerchantLogin.tsx         # Page de connexion marchand
│   ├── MerchantDashboard.tsx     # Tableau de bord marchand
│   ├── MerchantCashier.tsx       # Interface de caisse
│   ├── MerchantStock.tsx         # Gestion des stocks
│   ├── MerchantTransactions.tsx  # Historique des transactions
│   ├── MerchantProfile.tsx       # Profil du marchand
│   ├── MerchantCredits.tsx       # Gestion des crédits clients
│   ├── MerchantSuppliers.tsx     # Commandes fournisseurs
│   ├── MerchantPromotions.tsx    # Gestion des promotions
│   ├── MerchantInvoices.tsx      # Facturation
│   ├── MerchantWallet.tsx        # Portefeuille électronique
│   ├── MerchantMoney.tsx         # Gestion de l'argent
│   ├── MerchantScanner.tsx       # Scanner QR Code
│   ├── MerchantCMU.tsx           # Intégration CMU
│   ├── MerchantKyc.tsx           # Vérification KYC
│   ├── MerchantHelp.tsx          # Aide et support
│   ├── MerchantUnderstand.tsx    # Guide de compréhension
│   └── MerchantVoiceRegister.tsx # Inscription vocale
│
├── features_merchant/            # Logique métier des marchands
│   ├── components/               # Composants par fonctionnalité
│   │   ├── cashier/              # Composants de la caisse
│   │   ├── credits/              # Gestion des crédits
│   │   ├── daily-session/        # Sessions journalières
│   │   ├── invoices/             # Facturation
│   │   ├── profile/              # Profil
│   │   ├── promotions/           # Promotions
│   │   └── suppliers/            # Fournisseurs
│   ├── hooks/                    # Hooks React personnalisés
│   ├── services/                 # Services d'accès aux données
│   ├── types/                    # Types TypeScript
│   └── utils/                    # Utilitaires
│
├── components_merchant/          # Composants UI réutilisables
│   ├── dashboard/                # Composants du tableau de bord
│   ├── stock/                    # Composants de gestion de stock
│   ├── AudioBars.tsx             # Indicateur audio
│   ├── CalculatorKeypad.tsx      # Pavé numérique
│   ├── CashDenominationPad.tsx   # Sélection des billets/pièces
│   ├── ProductSelector.tsx       # Sélecteur de produits
│   ├── QRReceipt.tsx             # Reçu avec QR Code
│   └── ...
│
├── markets/                      # Composants liés aux marchés
│   ├── CategoryCarousel.tsx      # Carrousel de catégories
│   ├── PriceCompareSheet.tsx     # Comparaison de prix
│   ├── ProductCard.tsx           # Carte produit
│   ├── ProductGrid.tsx           # Grille de produits
│   └── QuantitySelector.tsx      # Sélecteur de quantité
│
├── hooks/                        # Hooks globaux
│   ├── useMerchantDashboardData.ts
│   ├── useMerchantNotifications.ts
│   └── useMarketBackground.ts
│
└── data/                         # Données statiques
    ├── markets.csv               # Liste des marchés
    └── marche-ivoirien.jpg       # Image de fond
```

## Dépendances Requises

Pour intégrer ces fichiers, vous aurez besoin des dépendances suivantes :

```json
{
  "@radix-ui/react-*": "^1.x",
  "@supabase/supabase-js": "^2.x",
  "@tanstack/react-query": "^5.x",
  "framer-motion": "^12.x",
  "lucide-react": "^0.4x",
  "react": "^18.x",
  "react-hook-form": "^7.x",
  "recharts": "^2.x",
  "sonner": "^1.x",
  "tailwind-merge": "^2.x",
  "zod": "^3.x"
}
```

## Notes d'Intégration

1. **Alias de chemin** : Les imports utilisent l'alias `@/` qui pointe vers `src/`. Configurez votre bundler en conséquence.

2. **Supabase** : Les services utilisent le client Supabase. Vous devrez adapter les imports selon votre configuration.

3. **Contextes React** : Certains composants dépendent de contextes globaux (`AuthContext`, `LanguageContext`, `AudioContext`).

4. **Composants UI** : Les composants utilisent shadcn/ui. Assurez-vous d'avoir les composants de base installés.

5. **Traductions** : Le système multilingue utilise un fichier `translations.ts` non inclus ici.

## Marchés Disponibles (markets.csv)

| Marché | Effectif Déclaré |
|--------|------------------|
| PACA | 514 marchands |
| BISSATA | 132 marchands |
| COVIYOP | 36 marchands |
| CO.MAR.VISCOOP | 23 marchands |
| UNICOVIA | 106 marchands |
| COOFEPALME | 107 marchands |
| COCOVICO | 175 marchands |
| SION | 85 marchands |
